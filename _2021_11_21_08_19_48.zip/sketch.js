
var ssurl = 'https://docs.google.com/spreadsheets/d/1O1dHCAAhHC3Rx1qpTyYAn2zfXDtiTKsVOrCds2Cr5hc/gviz/tq?tqx=out:json&gid=0';
var sscons = [];

function preload(){
  
  $.ajax({url: ssurl, type: 'GET', dataType: 'text'})
    .done((data)=> {
   
      const r = data.match(/google\.visualization\.Query\.setResponse\(([\s\S\w]+)\)/);
      if (r && r.length == 2) {
        const obj = JSON.parse(r[1]);
        console.log(obj);
        obj.table.rows.forEach((robj)=>{
          let roweach = {};
          obj.table.cols.forEach((l,i)=>{
            roweach[l.label]=robj.c[i].v;
          });
          sscons.push(roweach);
        });
      }
      console.log(sscons);
    });
}
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  sscons.forEach((o)=>{
  circle(o.x,o.y,50);
  });
}